export default function handler(req, res) {
  if (req.method === 'POST') {
    const { name, job } = req.body;
    console.log("Received lead:", name, job);
    res.status(200).json({ message: "Lead submitted successfully!" });
  } else {
    res.status(405).end();
  }
}