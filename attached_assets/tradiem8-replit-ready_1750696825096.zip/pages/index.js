export default function Home() {
  return (
    <div>
      <h1>Welcome to TradieM8 👷‍♂️</h1>
      <p>Your digital tradie assistant.</p>
    </div>
  );
}