export default function Bookings() {
  return (
    <div>
      <h1>📆 Bookings</h1>
      <p>This page will be used to create or view job bookings.</p>
    </div>
  );
}