import { useState } from 'react';

export default function Leads() {
  const [form, setForm] = useState({ name: '', job: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/submitLead', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    alert(data.message);
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
      <input placeholder="Job Description" value={form.job} onChange={e => setForm({ ...form, job: e.target.value })} />
      <button type="submit">Submit Lead</button>
    </form>
  );
}