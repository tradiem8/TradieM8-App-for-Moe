export default function Invoices() {
  return (
    <div>
      <h1>🧾 Invoices</h1>
      <p>This page will allow you to create and send invoices.</p>
    </div>
  );
}