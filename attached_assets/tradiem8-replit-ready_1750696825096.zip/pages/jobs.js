import { useState } from 'react';

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [job, setJob] = useState({ client: '', date: '', price: '' });

  const addJob = () => {
    setJobs([...jobs, job]);
    setJob({ client: '', date: '', price: '' });
  };

  return (
    <div>
      <h1>📋 Job List</h1>
      <input placeholder="Client" value={job.client} onChange={e => setJob({ ...job, client: e.target.value })} />
      <input type="date" value={job.date} onChange={e => setJob({ ...job, date: e.target.value })} />
      <input placeholder="Price" value={job.price} onChange={e => setJob({ ...job, price: e.target.value })} />
      <button onClick={addJob}>Add Job</button>
      <ul>
        {jobs.map((j, i) => (
          <li key={i}>{j.client} - {j.date} - ${j.price}</li>
        ))}
      </ul>
    </div>
  );
}