import Image from 'next/image';
import Link from 'next/link';

const layoutStyle = {
  backgroundColor: '#0A0A0A',
  color: '#FFFFFF',
  minHeight: '100vh',
  fontFamily: 'sans-serif',
  padding: '20px'
};

const navLink = {
  display: 'inline-block',
  marginRight: '15px',
  color: '#FFEB3B',
  textDecoration: 'none',
  fontWeight: 'bold'
};

export default function Layout({ children }) {
  return (
    <div style={layoutStyle}>
      <header style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
        <Image src="/logo.png" alt="TradieM8 Logo" width={100} height={100} />
        <nav style={{ marginLeft: '20px' }}>
          <Link href="/dashboard" style={navLink}>Dashboard</Link>
          <Link href="/jobs" style={navLink}>Jobs</Link>
          <Link href="/bookings" style={navLink}>Bookings</Link>
          <Link href="/invoices" style={navLink}>Invoices</Link>
          <Link href="/leads" style={navLink}>Leads</Link>
        </nav>
      </header>
      <main>{children}</main>
    </div>
  );
}